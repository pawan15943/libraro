@extends('layouts.admin')

@section('content')
<link rel="stylesheet" href="{{ asset('public/css/library-style.css') }}">

<div class="actions mb-4">
    <div class="upper-box">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mb-3">{{ $branch->display_name ?? $branch->name }} — Plans</h4>
            <a href="javascript:void(0);" class="go-back" onclick="window.history.back();">Go Back <i class="fa-solid fa-backward pl-2"></i></a>
        </div>
    </div>
</div>

@if(session('success'))
<div class="alert alert-success">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
@if($errors->any())
<div class="alert alert-danger">
    <ul class="m-0">
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif

<div class="card p-3 mb-4">
    <div class="d-flex justify-content-between align-items-center">
        <h5 class="m-0" id="planFormTitle">{{ old('id') ? 'Edit Plan' : 'Add Plan' }}</h5>
        <button type="button" class="btn btn-sm btn-primary" id="togglePlanForm"><i class="fa-solid fa-plus"></i> Add Plan</button>
    </div>

    <form id="planForm" method="POST" action="{{ route('library.branch.plans.save', $branch->id) }}" class="mt-3" style="{{ $errors->any() ? '' : 'display:none;' }}">
        @csrf
        <input type="hidden" name="id" id="plan_id_field" value="{{ old('id') }}">
        <div class="row g-4">
            <div class="col-lg-4">
                <label>Type <span>*</span></label>
                <select class="form-select @error('type') is-invalid @enderror" name="type" id="plan_type" required>
                    <option value="">Select Type</option>
                    <option value="MONTH" @selected(old('type') == 'MONTH')>MONTH</option>
                    <option value="YEAR" @selected(old('type') == 'YEAR')>YEAR</option>
                    <option value="DAY" @selected(old('type') == 'DAY')>DAY</option>
                    <option value="WEEK" @selected(old('type') == 'WEEK')>WEEK</option>
                </select>
                @error('type')
                <span class="invalid-feedback d-block">{{ $message }}</span>
                @enderror
            </div>
            <div class="col-lg-4">
                <label>Plan (digits) <span>*</span></label>
                <input type="number" min="1" class="form-control @error('plan_id') is-invalid @enderror" name="plan_id" id="plan_number" value="{{ old('plan_id') }}" required placeholder="Ex: 1 for 1 Month">
                @error('plan_id')
                <span class="invalid-feedback d-block">{{ $message }}</span>
                @enderror
            </div>
            <div class="col-lg-4">
                <label>Monthly Days</label>
                <select class="form-select @error('monthdays') is-invalid @enderror" name="monthdays" id="plan_monthdays">
                    <option value="" @selected(old('monthdays') === null)>Calendar-wise (automatic)</option>
                    <option value="28" @selected(old('monthdays') == 28)>28 days</option>
                    <option value="30" @selected(old('monthdays') == 30)>30 days</option>
                </select>
                @error('monthdays')
                <span class="invalid-feedback d-block">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-primary" id="savePlanBtn">{{ old('id') ? 'Update Plan' : 'Add Plan' }}</button>
        </div>
    </form>
</div>

@if($branchPlans->isEmpty())
<div class="no-data-found">
    <h4>No plans added for this library yet.</h4>
</div>
@else
<div class="plan-price-module">
    <div class="row g-4 mb-4">
        @foreach($branchPlans as $key => $plan)
        @php
            $isInactive = (bool) $plan->deleted_at;
        @endphp
        <div class="col-lg-4 col-md-6">
            <div class="plan-price-card">
                <div class="plan-card-body">
                    <!-- Card Header: Title & Status -->
                    <div class="plan-card-header">
                        <h4 class="plan-card-title">{{ $plan->name }}</h4>
                        @if($isInactive)
                        <span class="plan-status-badge inactive">
                            <span class="status-dot"></span> INACTIVE
                        </span>
                        @else
                        <span class="plan-status-badge active">
                            <span class="status-dot"></span> ACTIVE
                        </span>
                        @endif
                    </div>

                    <!-- Duration Pill Badge -->
                    <div class="plan-duration-badge mb-3">
                        <i class="fa-regular fa-clock me-1.5" style="color: #18225f;"></i> {{ $plan->plan_id }} {{ $plan->type }}{{ (int)$plan->plan_id > 1 ? 'S' : '' }}
                    </div>

                    <!-- Metadata Grid -->
                    <div class="plan-meta-grid">
                        <div class="plan-meta-item">
                            <div class="plan-meta-label">Plan Name</div>
                            <div class="plan-meta-value text-truncate" title="{{ $plan->name }}">{{ $plan->name }}</div>
                        </div>
                        <div class="plan-meta-item">
                            <div class="plan-meta-label">Type</div>
                            <div class="plan-meta-value">{{ $plan->type }}</div>
                        </div>
                        <div class="plan-meta-item">
                            <div class="plan-meta-label">Plan Number</div>
                            <div class="plan-meta-value">{{ $plan->plan_id }}</div>
                        </div>
                        <div class="plan-meta-item">
                            <div class="plan-meta-label">Plan Days</div>
                            <div class="plan-meta-value">{{ $plan->monthdays ?: 'Automatic (Calendar)' }}</div>
                        </div>
                    </div>
                </div>

                <!-- Bottom Action Buttons Row -->
                <div class="plan-card-actions">
                    <a href="javascript:void(0)" class="btn-plan-action btn-action-edit plan-edit"
                        data-id="{{ $plan->id }}"
                        data-type="{{ $plan->type }}"
                        data-plan-id="{{ $plan->plan_id }}"
                        data-monthdays="{{ $plan->monthdays }}"
                        title="Edit Plan">
                        <i class="fa-solid fa-pen-to-square me-1"></i> Edit
                    </a>

                    <a href="javascript:void(0)" class="btn-plan-action btn-action-delete plan-delete"
                        data-url="{{ route('library.branch.plans.delete', $plan->id) }}"
                        title="Delete Plan">
                        <i class="fa-solid fa-trash me-1"></i> Delete
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

<script>
document.getElementById('togglePlanForm').addEventListener('click', function () {
    const form = document.getElementById('planForm');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
    document.getElementById('plan_id_field').value = '';
    document.getElementById('planForm').reset();
    document.getElementById('planFormTitle').textContent = 'Add Plan';
    document.getElementById('savePlanBtn').textContent = 'Add Plan';
});

document.querySelectorAll('.plan-edit').forEach(function (link) {
    link.addEventListener('click', function () {
        document.getElementById('planForm').style.display = 'block';
        document.getElementById('plan_id_field').value = this.dataset.id;
        document.getElementById('plan_type').value = this.dataset.type;
        document.getElementById('plan_number').value = this.dataset.planId;
        document.getElementById('plan_monthdays').value = this.dataset.monthdays || '';
        document.getElementById('planFormTitle').textContent = 'Edit Plan';
        document.getElementById('savePlanBtn').textContent = 'Update Plan';
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});

document.querySelectorAll('.plan-delete').forEach(function (link) {
    link.addEventListener('click', function () {
        const url = this.dataset.url;
        Swal.fire({
            title: 'Delete this plan?',
            text: 'This cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete'
        }).then(function (result) {
            if (result.isConfirmed) {
                fetch(url, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json',
                    }
                }).then(function (res) { return res.json(); })
                  .then(function () { window.location.reload(); })
                  .catch(function () { Swal.fire('Error', 'Failed to delete plan.', 'error'); });
            }
        });
    });
});
</script>
@endsection
